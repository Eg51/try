import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  cacheComponents: true,
  partialPrefetching: true,
  
  // FIX: Tell Next.js to treat Firebase and its dependencies as external packages
  serverExternalPackages: ["firebase-admin", "jwks-rsa", "jose"],
  
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;